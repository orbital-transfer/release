DO NOT RUN FirstParaffinRun.cmd!

I included this to show you the command lines how I initially created the .WXS 
fragments for this installation.

Running UpdateParaffinRun.cmd is fine as it creates the .PARAFFIN files, which 
do not overwrite the .WXS files.